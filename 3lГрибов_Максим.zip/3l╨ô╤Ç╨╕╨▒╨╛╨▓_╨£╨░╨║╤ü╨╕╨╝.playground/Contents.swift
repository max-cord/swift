import UIKit

/*
1. Описать несколько структур – любой легковой автомобиль SportCar и любой грузовик TrunkCar.
2. Структуры должны содержать марку авто, год выпуска, объем багажника/кузова, запущен ли двигатель, открыты ли окна, заполненный объем багажника.
3. Описать перечисление с возможными действиями с автомобилем: запустить/заглушить двигатель, открыть/закрыть окна, погрузить/выгрузить из кузова/багажника груз определенного объема.
4. Добавить в структуры метод с одним аргументом типа перечисления, который будет менять свойства структуры в зависимости от действия.
5. Инициализировать несколько экземпляров структур. Применить к ним различные действия.
6. Вывести значения свойств экземпляров в консоль.
*/

enum Windows {
    case open, close
}

enum Engine {
    case turnon, turnoff
}

enum Model: String  {
    case lada = "Лада"
    case lexus = "Лекус"
    case chrysler = "Крайслер"
    case infinity = "Инфинити"
    case opel = "Opel"
    case nissan = "Nissan"
    case volvo = "Volvo"
    case scania = "Scania"
    case kamaz = "Камаз"
    case mercedes = "Mercedes"
}

struct SportCar {
    let model: Model //Марка машины
    let year: Int //год выпуска
    let trunkVolFull: Double //Объем багажника
    var cargo: Double {// груз
        willSet {
            if cargo > trunkVolFull {
                print("Вы загрузили багажник на вес \(cargo)")
            } else if cargo == 0 {
                print("Багажник полон")
            } else {
                print("Не влезает")
            }
        }
    }
    
    var engine: Engine // Двигатель
    
    mutating func turnOff() {
        self.engine = .turnoff
    }
    
    mutating func turnOn() {
        self.engine = .turnon
    }
    
    var windows: Windows { //окна
        
        willSet {
            if newValue == .open {
                print("Окна открыты")
            } else {
                print("Окна закрыты")
            }
        }
    }
    
}

struct TrunkCar {
 let model: Model //Марка машины
 let year: Int //год выпуска
 let trunkVolFull: Double //Объем багажника
 var cargo: Double
 
 var engine: Engine // Двигатель
 mutating func turnOff() {
     self.engine = .turnoff
 }
 mutating func turnOn() {
     self.engine = .turnon
 }
 
 var windows: Windows { //окна
     willSet {
         if newValue == .open {
             print("Окна открыты")
         } else {
             print("Окна закрыты")
         }
     }
 }
}


func printSportCarProperties(car: SportCar) {
    print("-----------------------------------")
    print("Модель авто:  \(car.model)")
    print("Год выпуска: \(car.year)")
    print("Объем багажника: \(car.trunkVolFull) литров")
    print("Состояние двигателя: \(car.engine == .turnon ? "Двигатель запущен" : "Двигатель заглушен")")
    print("Окна: \(car.windows == .open ? "Открыты" : "Закрыты")")
    print("Размер груза: \(car.cargo)")
    print("\(car.cargo < car.trunkVolFull ? "Груз влез" : "Груз не влазит")")
}

func printTrunkCarProperties(trunkcar: TrunkCar) {
    print("-----------------------------------")
    print("Модель авто:  \(trunkcar.model)")
    print("Год выпуска: \(trunkcar.year)")
    print("Объем багажника: \(trunkcar.trunkVolFull) литров")
    print("Состояние двигателя: \(trunkcar.engine == .turnon ? "Двигатель запущен" : "Двигатель заглушен")")
    print("Окна: \(trunkcar.windows == .open ? "Открыты" : "Закрыты")")
    print("Размер груза: \(trunkcar.cargo)")
    print("\(trunkcar.cargo < trunkcar.trunkVolFull ? "Груз влез" : "Груз не влазит")")
}

var sportcar1 = SportCar(model: .lexus, year: 2019, trunkVolFull: 35, cargo: 20.0, engine: .turnoff, windows: .close)
var sportcar2 = SportCar(model: .lada, year: 2016, trunkVolFull: 60.2, cargo: 60.2, engine: .turnon, windows: .open)
var trunkcar1 = TrunkCar(model: .mercedes, year: 2010, trunkVolFull: 1000, cargo: 220, engine: .turnoff, windows: .close)
var trunkcar2 = TrunkCar(model: .kamaz, year: 2008, trunkVolFull: 1500, cargo: 220, engine: .turnoff, windows: .open)

sportcar2.cargo = 180
sportcar2.engine = .turnoff
sportcar1.windows = .close
sportcar1.engine = .turnon
trunkcar2.engine = .turnon
trunkcar1.engine = .turnon
trunkcar1.cargo = 2000
printSportCarProperties(car: sportcar2)
printSportCarProperties(car: sportcar1)
printTrunkCarProperties(trunkcar: trunkcar1)
printTrunkCarProperties(trunkcar: trunkcar2)


